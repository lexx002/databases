
phone_list = [
    {
        'model_name' : 'Galaxy S',
        'producer' : 'Samsung',
        'cost' : 28990,
        'operation_system' : 'Android 7.0',
        'ram' : 2000,
        'core' : 4,
        'memory' : 128,
        'display_definition' : '3000 x 2650',
        'double_camera' : True,
        'battery' : 3500
    },
    {
        'model_name' : 'Galaxy J',
        'producer' : 'Samsung',
        'cost' : 7990,
        'operation_system' : '',
        'ram' : 1300,
        'core' : 2,
        'memory' : 32,
        'display_definition' : '1440 x 2650',
        'double_camera' : True,
        'battery' : 3200
    },
]